# Ruby on Rails Tutorial: sample application

(http://www.michaelhartl.com/)